import data.scripts.CozyPerformance;
import data.scripts.CozyUi;

// Shared by all four songs; engine pause/retry/resync remain native.
var cozySongLabel;
var cozyClock;
var cozyProgress;
var cozyParticles = [];
var cozyTime = 0.0;
var cozyEffects = true;
var cozyCameraFocusX = 640.0;
var cozyScenery = [];

function postCreate() {
    playCutscenes = true;
    cozyEffects = FlxG.save.data.cozyEffects != false && FlxG.save.data.cozyReducedMotion != true;
    muteVocalsOnMiss = false;
    if (FlxG.save.data.cozyPractice == true) validScore = false;
    // Codename's HudCamera already mirrors Y in downscroll. Applying that
    // choice twice puts the health bar over the lower receptors.
    healthBarBG.y = FlxG.height - 110;
    healthBar.y = healthBarBG.y + 4;
    for (icon in iconArray) icon.y = healthBar.y - icon.height / 2;
    // Keep statistics clear of the 150px icons, also after camera mirroring.
    for (label in [scoreTxt, missesTxt, accuracyTxt]) label.y = FlxG.height - 22;
    var title = SONG.meta.displayName;
    cozySongLabel = new FunkinText(26, 12, 760, title + "  /  " + PlayState.difficulty.toUpperCase(), 21);
    cozySongLabel.setFormat(Paths.font("AtkinsonHyperlegible-Regular.ttf"), 21, 0xFFFFE1B1, "left");
    cozySongLabel.cameras = [camHUD];
    cozySongLabel.borderColor = 0xFF271B2D;
    add(cozySongLabel);
    cozyClock = new FunkinText(1010, 12, 245, "", 21);
    cozyClock.setFormat(Paths.font("AtkinsonHyperlegible-Regular.ttf"), 21, 0xFFFFE1B1, "right");
    cozyClock.cameras = [camHUD];
    cozyClock.borderColor = 0xFF271B2D;
    add(cozyClock);
    cozyProgress = new FlxSprite(0, 0).makeGraphic(1280, 4, 0xFFF5BD87);
    cozyProgress.cameras = [camHUD];
    cozyProgress.scale.x = .001;
    cozyProgress.origin.set(0, 0);
    add(cozyProgress);
    if (FlxG.save.data.cozyPractice == true) {
        var label = new FunkinText(430, 37, 420, "PRÁTICA · SEM DERROTA / SEM RECORDE", 18);
        label.setFormat(Paths.font("AtkinsonHyperlegible-Regular.ttf"), 18, 0xFFFFC5E0, "center");
        label.cameras = [camHUD];
        add(label);
    }
    if (cozyEffects) {
        for (i in 0...8) {
            var dot = new FlxSprite(-200 + (i * 173) % 1750, 40 + (i * 83) % 700);
            dot.makeGraphic(SONG.stage == "sakura-garden" ? 8 : 4, SONG.stage == "sakura-garden" ? 4 : 4, SONG.stage == "sakura-garden" ? 0xFFF4B3C7 : 0xFFFFD99A);
            dot.alpha = .28;
            dot.scrollFactor.set(.85, .85);
            add(dot);
            cozyParticles.push(dot);
        }
    }
    // Frame against both characters; small musical camera motions stay within the background.
    camFollow.setPosition(640, 360);
    allowGitaroo = false;
    if (cozyUseNewArt()) {
        var artPath = Paths.file("data/characters/bf-night.xml");
        if (Assets.exists(artPath)) {
            try { boyfriend.applyXML(Xml.parse(Assets.getText(artPath)).firstElement()); }
            catch (error:Dynamic) {
                boyfriend.applyXML(Xml.parse(Assets.getText(Paths.file("data/characters/bf-cozy.xml"))).firstElement());
                trace("COZY_ART_FALLBACK " + error);
            }
        }
        var backdrop = stage.getSprite("cozyBackdrop");
        if (backdrop != null) {
            backdrop.loadGraphic(Paths.image(cozyStageImage(SONG.stage)));
            // Uniform scaling retains the existing stage framing and overscan.
            var artScale = Math.max(1806 / backdrop.width, 1017 / backdrop.height);
            backdrop.scale.set(artScale, artScale);
            backdrop.updateHitbox();
        }
    }
    cozyInitPerformance();
    cozyScenery = cozyAmbient(SONG.stage, true);
    trace("COZY gameplay ready: " + SONG.meta.name + " / " + PlayState.difficulty + " / player=" + boyfriend.curCharacter + " / opponent=" + dad.curCharacter);
}

function onCameraMove(event) {
    event.position.set(640, 360);
}

function onPlayerMiss(event) {
    // Missing an arrow still affects score, health and the native miss SFX.
    cozyPerformanceMiss(event);
    if (FlxG.save.data.cozyPractice == true) {
        event.healthGain = 0;
    }
}

function onNoteHit(event) {
    cozyDefaultHitAnimation(event);
    if (!cozyEffects) event.preventCamZooming();
}

function onVocalsResync() {
    cozyPerformanceSeek();
}

function onGameOver(event) {
    if (FlxG.save.data.cozyPractice == true) {
        event.cancel();
        health = 1;
    }
}

function update(elapsed) {
    cozyTime = Math.max(0, cozyAudioTime()) / 1000;
    if (FlxG.keys.justPressed.F11) FlxG.fullscreen = !FlxG.fullscreen;
    if (cozyClock != null && inst != null && inst.length > 0) {
        var seconds = Std.int(cozyTime);
        var total = Std.int(inst.length / 1000);
        cozyClock.text = Std.int(seconds / 60) + ":" + StringTools.lpad(Std.string(seconds % 60), "0", 2) + " / " + Std.int(total / 60) + ":" + StringTools.lpad(Std.string(total % 60), "0", 2);
        cozyProgress.scale.x = Math.max(.001, Math.min(1, cozyTime * 1000 / inst.length));
    }
}

function postUpdate(elapsed) {
    cozyUpdatePerformance(elapsed);
    if (inCutscene || startingSong || paused || endingSong) return;
    var musicalBeat = cozyTime * SONG.meta.bpm / 60;
    for (image in cozyScenery) image.angle = cozyEffects ? Math.sin(cozyTime * 1.2) * 1.2 : 0;
    var phase = musicalBeat - Math.floor(musicalBeat);
    // Wider framing belongs to the duet; solo answers receive a small focus shift.
    var focusX = cozyVocalState == "LILA" ? 626 : cozyVocalState == "BF" ? 654 : 640;
    cozyCameraFocusX += ((cozyEffects ? focusX : 640) - cozyCameraFocusX) * Math.min(1, elapsed * 7);
    var cinemaCamera = cozyCinemaCamera(cozyTime * 1000);
    camFollow.setPosition(Math.max(620, Math.min(660, cozyCameraFocusX + cinemaCamera.x)), 360);
    var targetZoom = (cozyEffects && cozyVocalState == "DUAL" ? .835 : .85) + cinemaCamera.zoom;
    defaultCamZoom += (targetZoom - defaultCamZoom) * Math.min(1, elapsed * 7);
    if (!cozyEffects) {
        camZooming = false;
        camGame.zoom = defaultCamZoom;
        camHUD.zoom = 1;
    }
    for (i in 0...cozyParticles.length) {
        var dot = cozyParticles[i];
        dot.x = -200 + ((i * 173 + cozyTime * (5 + (i % 5) * 2)) % 1750);
        dot.y = 40 + (i * 83) % 700 + Math.sin(musicalBeat * Math.PI / 8 + i) * 5;
        dot.alpha = (cozyVocalState == "DUAL" ? .29 : .20) + .09 * Math.max(0, 1 - phase * 4);
    }
}

function destroy() {
    cozyDestroyMotion();
    for (dot in cozyParticles) FlxTween.cancelTweensOf(dot);
    for (image in cozyScenery) {
        FlxTween.cancelTweensOf(image);
        remove(image, true);
        image.destroy();
    }
    cozyScenery = [];
}

