import data.scripts.CozyDialogue;
