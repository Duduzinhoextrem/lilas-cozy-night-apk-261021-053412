import data.scripts.CozyUi;
import data.scripts.CozyMotion;
import data.scripts.CozyPaper;

var cinemaCamera;
var cinemaUiCamera;
var cinemaObjects=[];
var cinemaSounds=[];
var cinemaTweens=[];
var cinemaActors=[];
var cinemaData;
var cinemaCue=-1;
var cinemaAction=0;
var cinemaAge=0.0;
var cinemaSceneAge=0.0;
var cinemaInputAge=0.0;
var cinemaTypedAge=0.0;
var cinemaFullText="";
var cinemaDone=true;
var cinemaCallback;
var cinemaReduced=false;
var cinemaFinal=false;
var cinemaDedication=false;
var cinemaPages=[];
var cinemaPage=0;
var cinemaChapter=0;
var cinemaAfter=false;
var cinemaBackdrop;
var cinemaScenery=[];
var cinemaSceneryBases=[];
var cinemaReflections=[];
var cinemaDrift=false;
var cinemaBf;
var cinemaLila;
var cinemaPaper;
var cinemaPaperShown=false;
var cinemaPaperShade;
var cinemaLoosePaper;
var cinemaPetal;
var cinemaPetalMode="";
var cinemaPetalAge=0.0;
var cinemaLantern;
var cinemaLanternMode="";
var cinemaPanel;
var cinemaSpeaker;
var cinemaMessage;
var cinemaCaption;
var cinemaHeading;
var cinemaFade;
var cinemaView={cx:640.0,cy:360.0,zoom:1.0};

function cinemaOwn(object,ui=false) {
    object.cameras=[ui ? cinemaUiCamera : cinemaCamera];
    cinemaObjects.push(object);return object;
}
function cinemaActor(id) { return cinemaActors[id=="bf" ? 1 : 0]; }
function cinemaStart(index,after,callback) {
    cinemaClear();
    cinemaCallback=callback;cinemaDone=false;cinemaDedication=false;
    cinemaFinal=after && index==3;cinemaChapter=index;cinemaAfter=after;
    cinemaAge=cinemaInputAge=cinemaSceneAge=0;
    cinemaReduced=FlxG.save.data.cozyEffects==false || FlxG.save.data.cozyReducedMotion==true;
    cinemaCamera=new FlxCamera();FlxG.cameras.add(cinemaCamera,false);
    cinemaUiCamera=new FlxCamera();cinemaUiCamera.bgColor=0;FlxG.cameras.add(cinemaUiCamera,false);
    cameras=[cinemaCamera];pausable=false;
    var chapter=cozyProject().songs[index];
    var story=Json.parse(Assets.getText(Paths.file("data/cozy-story.json")));
    cinemaData=after ? story.chapters[index].after : story.chapters[index].before;
    cinemaBackdrop=cinemaOwn(cozyBackground(chapter.stage));
    cinemaScenery=cozyAmbient(chapter.stage);cinemaSceneryBases=[];cinemaReflections=[];cinemaDrift=false;
    for(o in cinemaScenery){cinemaOwn(o);cinemaSceneryBases.push({sprite:o,x:o.x,y:o.y});}
    if(index==3)for(i in 0...3)cinemaReflections.push(cinemaOwn(cozyBox(612-i*7,338+i*7,42+i*9,2,0xFFB5CCFF,.13)));
    cinemaLantern=cinemaOwn(new FlxSprite(1015,105).loadGraphic(Paths.image("props/lantern")));
    cinemaLantern.setGraphicSize(0,125);cinemaLantern.updateHitbox();cinemaLantern.visible=index==2;
    cinemaLanternMode="";
    cinemaLila=cinemaOwn(cozyPortrait("lila",325,0,450));
    cinemaBf=cinemaOwn(cozyPortrait("bf",730,0,390));
    var leftEntry=!after && index>0;
    cinemaActors=[
        {sprite:cinemaLila,x:leftEntry ? -170.0 : 325.0,ground:565.0,pose:"idle",moving:false,motion:cozyMotionCreate(cinemaLila,false,true)},
        {sprite:cinemaBf,x:!after && index==0 ? 1150.0 : leftEntry ? -365.0 : 730.0,ground:565.0,pose:"listen",moving:false,motion:cozyMotionCreate(cinemaBf,true,true)}
    ];
    cinemaActors[0].motion.footX=413;cinemaActors[0].motion.footY=971;
    cinemaLoosePaper=cinemaOwn(new FlxSprite().loadGraphic(Paths.image("props/cozy-list")));
    cinemaLoosePaper.setGraphicSize(65,0);cinemaLoosePaper.updateHitbox();cinemaLoosePaper.visible=false;
    cinemaPetal=cinemaOwn(new FlxSprite().loadGraphic(Paths.image("props/v3-petal")),true);cinemaPetal.visible=false;cinemaPetalMode="";
    cinemaPaperShade=cinemaOwn(cozyBox(0,0,1280,720,0xFF24192C,.68),true);cinemaPaperShade.visible=false;
    cinemaPaper=cozyPaperCreate(380,100,1);
    for(o in cinemaPaper.objects)cinemaOwn(o,true);
    cozyPaperState(cinemaPaper,index==0 ? (after ? 1 : 0) : index==1 ? (after ? 2 : 1) : index==2 ? (after ? 3 : 2) : 3,index>=2,"");
    cozyPaperVisible(cinemaPaper,false);cinemaPaperShown=false;
    // Petal must render over the paper during its close-up.
    remove(cinemaPetal,true);add(cinemaPetal);
    cinemaPanel=cinemaOwn(cozyBox(64,560,1152,116,0xFF211B2D,.95),true);
    cinemaSpeaker=cinemaOwn(cozyText(88,568,1104,"",22,0xFFFFC98E,true),true);
    cinemaMessage=cinemaOwn(cozyText(88,600,1104,"",27),true);
    cinemaHeading=cinemaOwn(cozyText(56,30,1170,"CAPÍTULO "+(index+1)+"  ·  "+story.chapters[index].title,27,0xFFFFD7A2,true),true);
    cinemaCaption=cinemaOwn(cozyText(64,691,1150,"",16,0xFFFFDFBD),true);
    cinemaFade=cinemaOwn(cozyBox(0,0,1280,720,0xFF171526,0),true);
    cinemaView={cx:640.0,cy:360.0,zoom:1.0};cinemaCamera.zoom=1;
    cinemaCue=-1;cinemaNext();cinemaRender(0);cozyMobileSetup(false);
    trace("COZY_CINEMA_START "+chapter.id+(after ? " outro" : " intro"));
}
function cinemaTween(target,key,to,duration) {
    var kept=[];
    for(t in cinemaTweens)if(t.target!=target || t.key!=key)kept.push(t);
    cinemaTweens=kept;
    if(cinemaReduced || duration<=0){Reflect.setProperty(target,key,to);return;}
    cinemaTweens.push({target:target,key:key,from:Reflect.getProperty(target,key),to:to,age:0.0,duration:duration});
}
function cinemaCommit() {
    for(t in cinemaTweens)Reflect.setProperty(t.target,t.key,t.to);
    cinemaTweens=[];
    for(actor in cinemaActors)actor.moving=false;
}
function cinemaApply(action,fast=false) {
    switch(action.op) {
        case "pose":
            var actor=cinemaActor(action.actor);actor.pose=action.name;
            if(!actor.moving)cozyPose(actor.sprite,actor.pose);
        case "move":
            var actor=cinemaActor(action.actor);actor.moving=!cinemaReduced && !fast;
            cinemaTween(actor,"x",action.x,fast ? 0 : action.duration);
        case "camera":
            var preset=action.preset;
            var cx=640.0;var cy=360.0;var zoom=1.0;
            if(preset=="duo"){cx=660;cy=360;zoom=1.12;}
            if(preset=="bf"){cx=850;cy=375;zoom=1.52;}
            if(preset=="lila"){cx=485;cy=325;zoom=1.42;}
            if(preset=="lantern"){cx=850;cy=280;zoom=1.55;}
            if(preset=="exit"){cx=720;zoom=1.15;}
            cinemaPaperShown=preset=="paper";
            cinemaPaperShade.visible=cinemaPaperShown;
            cozyPaperVisible(cinemaPaper,cinemaPaperShown);
            // State hides the optional doodle independently of the insert's visibility.
            if(cinemaPaperShown)cinemaPaper.doodle.visible=cinemaPaper.note.text.length>0;
            if(!cinemaPaperShown && cinemaPetalMode=="paper")cinemaPetal.visible=false;
            if(cinemaReduced){cx=640;cy=360;zoom=1;}
            cinemaTween(cinemaView,"cx",cx,fast ? 0 : action.duration);
            cinemaTween(cinemaView,"cy",cy,fast ? 0 : action.duration);
            cinemaTween(cinemaView,"zoom",zoom,fast ? 0 : action.duration);
        case "paper":
            cozyPaperState(cinemaPaper,action.completed,action.doodle,action.last);
            if(!cinemaPaperShown)cozyPaperVisible(cinemaPaper,false);
        case "prop":
            if(action.name=="paper") {
                if(action.effect=="open") {
                    cinemaLoosePaper.visible=false;
                    if(cinemaPaperShown){cozyPaperVisible(cinemaPaper,true);cinemaPaper.doodle.visible=cinemaPaper.note.text.length>0;}
                }
                if(action.effect=="stow")cinemaLoosePaper.visible=false;
                if(action.effect=="slip") {
                    cinemaLoosePaper.visible=true;cinemaLoosePaper.alpha=1;
                    cinemaLoosePaper.x=cinemaActor("bf").x+180;cinemaLoosePaper.y=350;cinemaLoosePaper.angle=-18;
                    cinemaTween(cinemaLoosePaper,"y",445,1.2);cinemaTween(cinemaLoosePaper,"angle",16,1.2);
                    cinemaTween(cinemaLoosePaper,"alpha",0,2.2);
                }
                if(action.effect=="mark") {
                    cinemaPaper.doodle.alpha=0;cinemaTween(cinemaPaper.doodle,"alpha",1,fast ? 0 : .65);
                }
            }
            if(action.name=="petal") {
                cinemaPetalMode=action.effect;cinemaPetalAge=0;cinemaPetal.visible=true;
            }
            if(action.name=="lantern") {
                cinemaLantern.visible=true;cinemaLanternMode=action.effect;
                if(action.effect=="dim")cinemaTween(cinemaLantern,"alpha",.35,fast ? 0 : 2);
            }
            if(action.name=="leaves"){cinemaDrift=true;for(o in cinemaScenery)o.alpha=.85;}
        case "sound":
            if(!fast)cinemaSounds.push(FlxG.sound.play(Paths.sound(action.name),action.volume));
        case "dialogue":
            if(!fast) {
                cinemaFullText=action.text;cinemaTypedAge=0;cinemaMessage.text="";
                cinemaSpeaker.text=action.speaker;cinemaSpeaker.color=action.speaker=="Boyfriend" ? 0xFF91D7E2 : 0xFFFFC98E;
                cinemaPanel.visible=cinemaSpeaker.visible=cinemaMessage.visible=true;
                if(action.speaker=="Boyfriend")cinemaSounds.push(FlxG.sound.play(Paths.sound("cozy-bop"),.22));
            }
        case "fade":cinemaTween(cinemaFade,"alpha",action.alpha,fast ? 0 : action.duration);
        case "wait": null;
        default:throw "Unknown cinema action: "+action.op;
    }
}
function cinemaNext() {
    if(cinemaDone)return;
    if(cinemaCue>=0 && cinemaCue<cinemaData.length) {
        var previous=cinemaData[cinemaCue];
        while(cinemaAction<previous.actions.length)cinemaApply(previous.actions[cinemaAction++],true);
        cinemaCommit();
    }
    cinemaCue++;
    if(cinemaCue>=cinemaData.length){if(cinemaFinal)cinemaShowDedication();else cinemaFinish();return;}
    cinemaAge=cinemaTypedAge=cinemaInputAge=0;cinemaAction=0;cinemaFullText="";
    cinemaPanel.visible=cinemaSpeaker.visible=cinemaMessage.visible=false;
    cinemaSpeaker.text=cinemaMessage.text="";
    cinemaCaption.text="B: pular cena";
    trace("COZY_CINEMA_CUE "+cinemaData[cinemaCue].id);
}
function cinemaRender(elapsed) {
    cinemaCamera.zoom=cinemaView.zoom;cinemaCamera.scroll.set(cinemaView.cx-640,cinemaView.cy-360);
    for(i in 0...cinemaActors.length) {
        var actor=cinemaActors[i];var image=actor.sprite;
        cozyMotionRestore(actor.motion);
        var stillMoving=false;for(t in cinemaTweens)if(t.target==actor)stillMoving=true;
        actor.moving=stillMoving;
        var pose=actor.pose;
        if(actor.moving)pose=i==1 ? "walk" : "walk";
        if(i==1 && !actor.moving && pose=="walk")pose="listen";
        cozyPose(image,pose);
        image.x=actor.x-(i==0 ? 200*image.scale.x : 0);
        image.y=actor.ground-(i==1 ? 488 : 971)*image.scale.y;
        var seated=actor.pose.indexOf("sit")==0;
        var mode=seated ? "SEATED" : cinemaFullText.length>0 && cinemaSpeaker.text==(i==1 ? "Boyfriend" : "Lila") ? "TALKING" : "LISTENING";
        cozyMotionStep(actor.motion,elapsed,cinemaSceneAge,cinemaSceneAge*.7,mode,0,"cue/"+cinemaCue,cinemaAge*1000,actor.moving ? 1 : 0,cinemaReduced);
    }
    for(o in cinemaScenery)o.angle=cinemaReduced ? 0 : Math.sin(cinemaSceneAge*1.2)*1.2;
    for(entry in cinemaSceneryBases) {
        entry.sprite.x=entry.x+(!cinemaReduced && cinemaDrift ? Math.sin(cinemaSceneAge*.4)*7 : 0);
        entry.sprite.y=entry.y+(!cinemaReduced && cinemaDrift ? Math.sin(cinemaSceneAge*.6)*2 : 0);
    }
    for(i in 0...cinemaReflections.length)cinemaReflections[i].alpha=cinemaReduced ? .13 : .13+Math.sin(cinemaSceneAge*.9+i)*.055;
    if(cinemaLantern.visible && !cinemaReduced)cinemaLantern.angle=Math.sin(cinemaSceneAge*1.4)*3;
    if(cinemaPetal.visible) {
        cinemaPetalAge+=elapsed;
        var p=cinemaReduced ? 1 : Math.min(1,cinemaPetalAge/2.8);
        cinemaPetal.x=cinemaPetalMode=="paper" ? 650+Math.sin(p*4)*35 : 1040-p*620;
        cinemaPetal.y=cinemaPetalMode=="paper" ? 50+p*265 : 95+p*320;
        cinemaPetal.angle=cinemaReduced ? 0 : p*160;
        if(cinemaPetalMode!="paper" && p>=1)cinemaPetal.visible=false;
    }
    cinemaHeading.alpha=cinemaSceneAge<2.5 ? 1 : Math.max(0,1-(cinemaSceneAge-2.5)/.6);
}
function cinemaUpdate(elapsed) {
    if(cinemaDone)return;
    cinemaInputAge+=elapsed;
    if(cinemaInputAge>.18 && cozyMobileBack()){cinemaSkip();return;}
    var accept=cinemaInputAge>.18 && cozyMobileAccept();
    if(cinemaDedication){if(accept)cinemaAccept();return;}
    cinemaAge+=elapsed;cinemaSceneAge+=elapsed;
    var cue=cinemaData[cinemaCue];
    while(cinemaAction<cue.actions.length && cue.actions[cinemaAction].at<=cinemaAge)cinemaApply(cue.actions[cinemaAction++]);
    var live=[];
    for(t in cinemaTweens) {
        t.age+=elapsed;var p=Math.min(1,t.age/t.duration);var eased=p*p*(3-2*p);
        Reflect.setProperty(t.target,t.key,t.from+(t.to-t.from)*eased);
        if(p<1)live.push(t);
    }
    cinemaTweens=live;cinemaRender(elapsed);
    if(cinemaFullText.length>0) {
        cinemaTypedAge+=elapsed;cinemaMessage.text=cinemaFullText.substr(0,Std.int(Math.min(cinemaFullText.length,cinemaTypedAge*42)));
        cinemaCaption.text="A: texto / próxima fala   ·   B: pular cena";
        if(accept)cinemaAccept();
    }else if(cinemaAge>=cue.duration)cinemaNext();
}
function cinemaAccept() {
    if(cinemaDone)return;cinemaInputAge=0;
    if(cinemaDedication) {
        cinemaPage++;
        if(cinemaPage>=cinemaPages.length)cinemaFinish();
        else {cinemaMessage.text=cinemaPages[cinemaPage];cinemaCaption.text="A: próxima página · B: resultado · "+(cinemaPage+1)+"/"+cinemaPages.length;}
    }else if(cinemaTypedAge*42<cinemaFullText.length){cinemaTypedAge=cinemaFullText.length/42;cinemaMessage.text=cinemaFullText;}
    else cinemaNext();
}
function cinemaShowDedication() {
    cinemaCommit();cinemaStopSounds();cinemaDedication=true;cinemaPage=0;cinemaInputAge=0;
    for(o in cinemaObjects)o.visible=false;
    cinemaBackdrop.visible=true;cinemaBackdrop.alpha=.35;
    cinemaCamera.zoom=1;cinemaCamera.scroll.set(0,0);
    cinemaPanel.visible=cinemaSpeaker.visible=cinemaMessage.visible=cinemaCaption.visible=true;
    cinemaPanel.makeGraphic(1152,570,0xFF211B2D);cinemaPanel.y=85;
    cinemaSpeaker.y=112;cinemaSpeaker.text="PRA LILA, COM CARINHO.";
    cinemaMessage.y=169;cinemaMessage.size=27;
    cinemaPages=[];var pageText="";
    for(paragraph in Assets.getText(Paths.file("data/cozy-dedication.txt")).split("\n\n")) {
        if(pageText.length>0 && pageText.length+paragraph.length>360){cinemaPages.push(pageText);pageText="";}
        pageText+=(pageText.length==0 ? "" : "\n\n")+paragraph;
    }
    if(pageText.length>0)cinemaPages.push(pageText);
    if(cinemaPages.length==0){cinemaFinish();return;}
    cinemaMessage.text=cinemaPages[0];cinemaCaption.text="A: próxima página · B: resultado · 1/"+cinemaPages.length;
    trace("COZY_DEDICATION_START");
}
function cinemaSkip(){if(cinemaDone)return;if(cinemaFinal && !cinemaDedication)cinemaShowDedication();else cinemaFinish();}
function cinemaFinish() {
    if(cinemaDone)return;cinemaDone=true;var callback=cinemaCallback;cinemaCallback=null;
    cinemaClear();trace("COZY_CINEMA_END");if(callback!=null)callback();
}
function cinemaStopSounds(){for(s in cinemaSounds)if(s!=null){s.stop();s.destroy();}cinemaSounds=[];}
function cinemaClear(disposed = false) {
    cozyMobileClear(disposed);
    cinemaDone=true;cinemaCallback=null;cinemaTweens=[];
    for(actor in cinemaActors)cozyMotionRestore(actor.motion);
    cinemaActors=[];cinemaStopSounds();
    for(o in cinemaObjects){FlxTween.cancelTweensOf(o);remove(o,true);o.destroy();}
    cinemaObjects=[];cinemaScenery=[];cinemaSceneryBases=[];cinemaReflections=[];cozyPortraitOffsets=[];
    if(cinemaCamera!=null && FlxG.cameras.list.contains(cinemaCamera))FlxG.cameras.remove(cinemaCamera,true);
    if(cinemaUiCamera!=null && FlxG.cameras.list.contains(cinemaUiCamera))FlxG.cameras.remove(cinemaUiCamera,true);
    cinemaCamera=cinemaUiCamera=null;
}
