// Android UI adapter for CPsP-Team Codename Engine Mobile (mobile-legacy).
// Gameplay notes and pause use the port's own hitbox; this owns menu buttons only.
var cozyMobileCameras = [];
var cozyMobileButtons = [];
var cozyMobilePads = [];

function cozyMobilePressed(id) {
    #if mobile
    return mobileCJustPressed(id);
    #else
    return false;
    #end
}

function cozyMobileAccept() {
    return FlxG.keys.justPressed.ENTER || FlxG.keys.justPressed.SPACE || cozyMobilePressed("ACCEPT");
}

function cozyMobileBack() {
    return FlxG.keys.justPressed.ESCAPE || cozyMobilePressed("BACK");
}

function cozyMobileSetup(menu = false) {
    #if mobile
    cozyMobileClear();
    var previousCameras = FlxG.cameras.list.copy();
    if (menu) addDPad("FULL");
    addButton(menu ? "A_B_X_Y" : "A_B");
    // Native button textures and coordinates; move the row clear of dialogue.
    for (button in mobileManager.buttons) button.y = 24;
    addButtonCamera();
    if (menu) addDPadCamera();
    cozyMobileButtons = mobileManager.buttons.copy();
    cozyMobilePads = mobileManager.dpads.copy();
    for (camera in FlxG.cameras.list)
        if (!previousCameras.contains(camera)) cozyMobileCameras.push(camera);
    trace("COZY_MOBILE_CONTROLS_READY " + (menu ? "menu" : "scene"));
    #end
}

function cozyMobileClear(disposed = false) {
    #if mobile
    // MusicBeatState/Substate call the script destroy hook AFTER native destroy.
    // At that point the manager already owns destruction of its children.
    if (!disposed && cozyMobileButtons.length > 0) {
        removeButton();
        for (button in cozyMobileButtons) button.destroy();
    }
    if (!disposed && cozyMobilePads.length > 0) {
        removeDPad();
        for (pad in cozyMobilePads) pad.destroy();
    }
    for (camera in cozyMobileCameras)
        if (FlxG.cameras.list.contains(camera)) FlxG.cameras.remove(camera, true);
    cozyMobileButtons = [];
    cozyMobilePads = [];
    cozyMobileCameras = [];
    #end
}
