// Beathoven only. Presentation uses the existing audio-ms clock and pose arbiter.
// No timers, note cancellation, extra cameras, actors or changes to the chart.
var cozyCinemaReady = false;
var cozyCinemaPreviousTime = -1.0;
var cozyCinemaEntries = 0;
var cozyCinemaStartMs = 250.0;
var cozyCinemaEndMs = 7250.0;

function cozyCinemaEligible() {
    return SONG.meta.name == "beathoven" && cozyUseNewArt();
}

function cozyCinemaAddFrames(combined) {
    if (!cozyCinemaEligible()) return;
    var atlas = Paths.getSparrowAtlas("characters/lila-story-v3");
    var first = combined.frames.length;
    cozyCopyPerformanceFrames(combined, atlas);
    for (i in first...combined.frames.length) {
        var frame = combined.frames[i];
        // Portrait canvas is translated by (+200,+100). Undo that registration
        // on owned frame copies; keep source pixels and original atlases intact.
        frame.offset.x -= 200;
        frame.offset.y -= 100;
        // Register the midpoint of the two feet (bottom 36px, alpha >=80)
        // to idle's (210.5,870). The portrait drawings are not foot-stable.
        var n = Std.parseInt(frame.name.substr(frame.name.length - 4));
        if (StringTools.startsWith(frame.name, "storyLaugh_")) {
            frame.offset.x += [20.5,22.0,5.5,11.0][n];
            frame.offset.y += 3;
        } else {
            frame.offset.x -= 1;
            frame.offset.y += [3,4,3,3][n];
        }
        frame.sourceSize.set(640, 872);
    }
}

function cozyCinemaInit() {
    if (!cozyCinemaEligible()) return;
    dad.addAnim("cozyCinemaLook", "storyLaugh_", 4, false, true, [0], 0, 0);
    dad.addAnim("cozyCinemaSmile", "storyLaugh_", 4, false, true, [0,1,1,3], 0, 0);
    dad.addAnim("cozyCinemaInvite", "storyInvite_", 6, false, true, [0,1,2,3,2,1,0], 0, 0);
    for (name in ["cozyCinemaLook", "cozyCinemaSmile", "cozyCinemaInvite"])
        if (!dad.hasAnimation(name)) throw "Missing cinema animation: " + name;
    if (!boyfriend.hasAnimation("cozyEncourage")) throw "Missing BF cinema response";
    cozyCinemaReady = true;
    trace("COZY_CINEMA_READY " + Json.stringify({song:SONG.meta.name,startMs:cozyCinemaStartMs,endMs:cozyCinemaEndMs,actors:2,newAssets:false}));
}

function cozyCinemaUpdate(time) {
    if (!cozyCinemaReady) return;
    // Rewind creates a new passage. Resync after a pause does not reset this
    // clock, and forward seeks reconstruct the pose without replaying the past.
    if (cozyCinemaPreviousTime >= 0 && time < cozyCinemaPreviousTime - .5)
        cozyCinemaPreviousTime = time < cozyCinemaStartMs ? -1 : time;
    if (cozyCinemaPreviousTime < cozyCinemaStartMs && time >= cozyCinemaStartMs && time < cozyCinemaEndMs) {
        cozyCinemaEntries++;
        trace("COZY_CINEMA_ENTER " + Json.stringify({pass:cozyCinemaEntries,timeMs:time}));
    }
    cozyCinemaPreviousTime = time;
}

function cozyCinemaPose(index, time) {
    if (!cozyCinemaReady) return null;
    if (index == 0 && time >= 250 && time < 850)
        return {animation:"cozyCinemaLook",id:"look",startMs:250.0};
    if (index == 0 && time >= 850 && time < 1850)
        return {animation:"cozyCinemaSmile",id:"smile",startMs:850.0};
    if (index == 1 && time >= 1900 && time < 2950)
        return {animation:"cozyEncourage",id:"response",startMs:1900.0};
    if (index == 0 && time >= 3100 && time < 4400)
        return {animation:"cozyCinemaInvite",id:"invite",startMs:3100.0};
    return null;
}

function cozyCinemaEase(t) {
    t = Math.max(0, Math.min(1, t));
    return t * t * (3 - 2 * t);
}

function cozyCinemaCamera(time) {
    if (!cozyCinemaReady || !cozyEffects || time < cozyCinemaStartMs || time >= cozyCinemaEndMs)
        return {x:0.0,zoom:0.0};
    var envelope = cozyCinemaEase((time - cozyCinemaStartMs) / 650) * cozyCinemaEase((cozyCinemaEndMs - time) / 1400);
    var response = cozyCinemaEase((time - 1600) / 500);
    var returnToLila = cozyCinemaEase((time - 2950) / 550);
    return {x:envelope * (-10 + 20 * response - 20 * returnToLila),zoom:envelope * .01};
}
