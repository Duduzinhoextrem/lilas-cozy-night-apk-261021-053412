import data.scripts.CozyCinema;

var resultCamera;
var resultAge = 0.0;
var resultFinished = false;
var resultBody;
var resultTitle;
var resultCaption;
var lastSong = false;
var celebration;
var outroBf;

function create() {
    if (PlayState.isStoryMode) {
        var project = cozyProject();
        var index = 0;
        for (i in 0...project.songs.length) if (project.songs[i].id == PlayState.SONG.meta.name) index = i;
        cinemaStart(index, true, function() { showResult(); });
    } else showResult();
}

function showResult() {
    pausable = false;
    resultCamera = new FlxCamera();
    FlxG.cameras.add(resultCamera, false);
    cameras = [resultCamera];
    var project = cozyProject();
    var current = project.songs[0];
    var songIndex = 0;
    for (i in 0...project.songs.length) if (project.songs[i].id == PlayState.SONG.meta.name) {
        current = project.songs[i];
        songIndex = i;
    }
    lastSong = PlayState.isStoryMode && songIndex == project.songs.length - 1;
    var bg=cozyBackground(current.stage);bg.cameras=[resultCamera];
    var shade=cozyBox(0,0,1280,720,0xFF24192C,.28);shade.cameras=[resultCamera];
    var box=cozyBox(746,148,470,460,0xFF241B30,.94);box.cameras=[resultCamera];
    celebration=cozyPortrait("lila",235,155,410);celebration.cameras=[resultCamera];
    outroBf=cozyPortrait("bf",420,231,350);outroBf.cameras=[resultCamera];outroBf.visible=true;
    cozyPose(celebration,lastSong ? "idle" : "invite");
    cozyPose(outroBf,lastSong ? "sitSmile" : "listen");
    var direction=PlayState.isStoryMode ? ["A CAMINHO DO JARDIM","AS LANTERNAS ESTÃO ACESAS","MAIS UM POUCO, SEM PRESSA","UMA NOITE PRA GUARDAR"][songIndex] : "MAIS UMA PRA CONTA";
    resultTitle=cozyText(64,52,1150,direction,35,0xFFFFD7A2,true);resultTitle.cameras=[resultCamera];
    var training = FlxG.save.data.cozyPractice == true;
    var autoplay = game.playerStrums.cpu;
    var mode = autoplay ? "REPRODUÇÃO AUTOMÁTICA · SEM RECORDE" : training ? "PRÁTICA · SEM RECORDE" : "MÚSICA CONCLUÍDA";
    var fraction = Math.isNaN(game.accuracy) ? 0 : Math.max(0, Math.min(1, game.accuracy));
    var percent = Math.floor(fraction * 10000) / 100;
    resultBody=cozyText(780,184,405,current.title+"\n"+PlayState.difficulty.toUpperCase()+"\n\nPontuação: "+game.songScore+"\nPrecisão: "+percent+"%\nErros: "+game.misses,27);resultBody.cameras=[resultCamera];
    var modeText=cozyText(780,473,400,mode,18,0xFFF1B9C9);modeText.cameras=[resultCamera];
    var next=PlayState.isStoryMode && !lastSong ? "Próximo: "+project.songs[songIndex+1].chapterTitle : lastSong ? "Obrigado por compartilhar essa noite." : "Outra música te espera no Freeplay.";
    var nextText=cozyText(64,620,1150,next,23,0xFFFFD7A2);nextText.cameras=[resultCamera];
    resultCaption=cozyText(64,675,1150,"A: "+(lastSong ? "encerrar a noite" : "continuar")+"   ·   B: continuar",19,0xFFF1B9C9);resultCaption.cameras=[resultCamera];
    FlxG.sound.playMusic(Paths.music("cozy-menu"),.25,true);
    if (!autoplay) {
        var stats = FlxG.save.data.cozyResults;
        if (stats == null) stats = {};
        var key = current.id + "_" + PlayState.difficulty + (training ? "_practice" : "_normal");
        var previous = Reflect.field(stats, key);
        if (training || previous == null || game.songScore > previous.score)
            Reflect.setField(stats, key, {score: game.songScore, accuracy: percent, misses: game.misses, practice: training});
        FlxG.save.data.cozyResults = stats;
        FlxG.save.flush();
    }
    cozyMobileSetup(false);
    trace("COZY result ready: " + current.id + " / " + PlayState.difficulty);
}

function finishResult() {
    if (resultFinished) return;
    resultFinished = true;
    close();
}

function advanceResult() { finishResult(); }

function update(elapsed) {
    if (!cinemaDone) { cinemaUpdate(elapsed); return; }
    resultAge += elapsed;
    if (resultFinished || resultAge < .3) return;
    if (cozyMobileBack()) {
        finishResult();
    }
    else if (cozyMobileAccept()) advanceResult();
}

function destroy() {
    cinemaClear(true);
    if (FlxG.sound.music != null) FlxG.sound.music.stop();
    if (resultCamera != null && FlxG.cameras.list.contains(resultCamera)) FlxG.cameras.remove(resultCamera, true);
}
