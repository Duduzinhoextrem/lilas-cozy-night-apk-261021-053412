import data.scripts.CozyUi;

var retryCamera;
var retryAge = 0.0;
var retryLeaving = false;

function create(event) {
    event.cancel();
    retryCamera = new FlxCamera();
    FlxG.cameras.add(retryCamera, false);
    cameras = [retryCamera];
    cozyBackground("cozy-room");
    cozyBox(0, 0, 1280, 720, 0xFF291B31, .65);
    cozyBox(80, 112, 1120, 475, 0xFFF1B17B, 1);
    cozyBox(86, 118, 1108, 463, 0xFF2C1D32, 1);
    cozyText(132, 158, 850, "BORA MAIS UMA?", 60, 0xFFFFD7A2, true);
    cozyText(138, 270, 620, "Lila: Relaxa. A resenha continua.\n\nDá pra tentar de novo, diminuir a\ndificuldade ou brincar na prática.\n\nA: tentar de novo\nB: voltar ao menu", 29);
    var tiredBf = cozyPortrait("bf", 850, 248, 285);
    cozyPose(tiredBf, "cozyGameOver");
    FlxG.sound.playMusic(Paths.music("cozy-menu"), .35, true);
    cozyMobileSetup(false);
    trace("COZY gentle game-over ready");
}

function update(elapsed) {
    retryAge += elapsed;
    if (retryLeaving || retryAge < .25) return;
    if (cozyMobileAccept()) {
        tryAgain();
    } else if (cozyMobileBack()) {
        retryLeaving = true;
        FlxG.switchState(new ModState("CozyMenu", {page: PlayState.isStoryMode ? "story" : "freeplay"}));
    }
}

function tryAgain() {
    if (retryLeaving) return;
    retryLeaving = true;
    FlxG.switchState(new PlayState());
}

function destroy() {
    cozyMobileClear(true);
    if (retryCamera != null && FlxG.cameras.list.contains(retryCamera)) FlxG.cameras.remove(retryCamera, true);
}
