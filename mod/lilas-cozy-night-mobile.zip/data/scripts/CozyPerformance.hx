import funkin.backend.assets.MultiFramesCollection;
import funkin.backend.utils.XMLUtil;
import Xml;
import data.scripts.CozyMotion;
import data.scripts.CozyGameplayCinema;

// Audio time is authoritative. Charts only drive scoring, receptors and input.
var cozyPerformanceReady = false;
var cozyPerformanceData;
var cozyPerformanceTime = -1.0;
var cozyPerformancePreviousTime = -1.0;
var cozyPerformanceLines = [[], []];
var cozyPerformanceEndPrefixes = [[], []];
var cozyPerformancePoseKeys = ["", ""];
var cozyPerformanceSpecialUntil = [-1.0, -1.0];
var cozyPerformanceModes = ["WAITING", "WAITING"];
var cozyPerformanceActive = [null, null];
var cozyPerformanceLastMiss = -1.0;
var cozyPerformanceMissDirection = 0;
var cozyVocalState = "INSTRUMENTAL";
var cozyLilaDanceReady = false;
var cozyPerformanceNotice;
var cozyBodyMotion = [null, null];

function cozyAudioTime() {
    // Conductor samples audio during preUpdate; Practice misses can make that
    // value a frame old by postUpdate. Use the live, interpolated audio clock.
    if (inst != null && !startingSong && inst.length > 0) return inst.time;
    return Conductor.songPosition + Options.songOffset;
}

function cozyPerformanceFailure(reason) {
    cozyPerformanceReady = false;
    trace("COZY_PERFORMANCE_ERROR " + SONG.meta.name + ": " + reason);
    if (cozyPerformanceNotice == null) {
        cozyPerformanceNotice = new FunkinText(20, 58, 1240, "Animação musical indisponível. Usando as poses clássicas.", 17);
        cozyPerformanceNotice.setFormat(Paths.font("AtkinsonHyperlegible-Regular.ttf"), 17, 0xFFFFB1B1, "center");
        cozyPerformanceNotice.cameras = [camHUD];
        add(cozyPerformanceNotice);
    }
}

function cozyCopyPerformanceFrames(combined, source) {
    var first = combined.frames.length;
    combined.addFrames(source);
    // Native addFrames shares frame objects. Its destructor would invalidate
    // the cached character atlas used by the next menu/song. Own only copies.
    for (index in first...combined.frames.length) {
        var copy = combined.frames[index].copyTo();
        combined.frames[index] = copy;
        combined.framesHash.set(copy.name, copy);
    }
}

function cozyAttachLilaDance() {
    if (dad == null || dad.curCharacter != "lila" || dad.frames == null) return;
    var configPath = Paths.file("data/cozy-performance-visuals.json");
    if (!Assets.exists(configPath)) throw "Missing dance calibration";
    var visual = Json.parse(Assets.getText(configPath));
    if (visual.schema != 1 || visual.lila == null) throw "Invalid dance calibration";
    var dancePath = Paths.image(visual.lila.danceAtlas);
    if (!Assets.exists(dancePath)) throw "Missing Lila dance atlas";
    // Combine once. Replacing frames during playback would clear native animations.
    var graphic = FlxG.bitmap.add("flixel/images/logo/default.png", false, cozyCinemaEligible() ? "cozy/lila-performance-cinema-v1" : "cozy/lila-performance-frames");
    var combined = MultiFramesCollection.findFrame(graphic);
    if (combined == null) {
        combined = new MultiFramesCollection(graphic);
        cozyCopyPerformanceFrames(combined, dad.frames);
        cozyCopyPerformanceFrames(combined, Paths.getSparrowAtlas(visual.lila.danceAtlas));
        cozyCinemaAddFrames(combined);
    }
    var oldAnimation = dad.getAnimName();
    dad.frames = combined;
    var characterXml = Xml.parse(Assets.getText(Paths.file("data/characters/lila.xml"))).firstElement();
    for (node in characterXml.elementsNamed("anim")) XMLUtil.addXMLAnimation(dad, node);
    for (anim in visual.lila.animations) {
        dad.addAnim(anim.name, anim.prefix, anim.fps, false, true, null, anim.offsetX, anim.offsetY);
        if (!dad.hasAnimation(anim.name)) throw "Missing dance animation: " + anim.name;
    }
    dad.playAnim(oldAnimation == null ? "idle" : oldAnimation, true, "DANCE");
    cozyCinemaInit();
    cozyLilaDanceReady = true;
}

function cozyInitPerformance() {
    // This is also set in modpack.ini, so normal/practice and every retry agree.
    muteVocalsOnMiss = false;
    var path = Paths.file("songs/" + SONG.meta.name + "/performance.json");
    try {
        if (!Assets.exists(path)) throw "Missing performance.json";
        cozyPerformanceData = Json.parse(Assets.getText(path));
        if (cozyPerformanceData.schema != 1 || cozyPerformanceData.timebase != "audio-ms" || cozyPerformanceData.song != SONG.meta.name)
            throw "Unsupported performance contract";
        if (cozyPerformanceData.events == null || cozyPerformanceData.events.length == 0 || cozyPerformanceData.durationMs <= 0)
            throw "Empty performance timeline";
        if (cozyPerformanceData.states == null || cozyPerformanceData.states.length == 0)
            throw "Missing performance states";
        for (note in cozyPerformanceData.events) {
            var index = note.singer == "lila" ? 0 : note.singer == "bf" ? 1 : -1;
            if (index < 0 || note.id == null || note.sourceNoteId == null || note.startMs == null || note.endMs == null
                || note.endMs <= note.startMs || note.startMs < 0 || note.endMs > cozyPerformanceData.durationMs
                || note.direction == null || note.direction < 0 || note.direction > 3)
                throw "Invalid performance event";
            cozyPerformanceLines[index].push(note);
        }
        for (index in 0...2) {
            cozyPerformanceLines[index].sort(function(a, b) { return a.startMs < b.startMs ? -1 : a.startMs > b.startMs ? 1 : 0; });
            var maximum = -1.0;
            for (note in cozyPerformanceLines[index]) {
                maximum = Math.max(maximum, note.endMs);
                cozyPerformanceEndPrefixes[index].push(maximum);
            }
        }
        cozyAttachLilaDance();
        if (!cozyLilaDanceReady) throw "Lila dance initialization did not finish";
        cozyPerformanceReady = true;
        cozyBodyMotion = [cozyMotionCreate(dad, false), cozyMotionCreate(boyfriend, true)];
        trace("COZY_PERFORMANCE_READY " + Json.stringify({song:SONG.meta.name,events:cozyPerformanceData.events.length,
            sourceEventsSha256:cozyPerformanceData.sourceEventsSha256,timebase:"audio-ms",lilaDance:cozyLilaDanceReady,muteVocalsOnMiss:muteVocalsOnMiss}));
    } catch (error:Dynamic) {
        cozyPerformanceFailure(Std.string(error));
    }
}

function cozyPerformanceIndexAt(index, time) {
    var notes = cozyPerformanceLines[index];
    var left = 0;
    var right = notes.length;
    while (left < right) {
        var middle = Std.int((left + right) / 2);
        if (notes[middle].startMs <= time) left = middle + 1;
        else right = middle;
    }
    return left - 1;
}

function cozyActivePerformanceEvent(index, time) {
    var notes = cozyPerformanceLines[index];
    var cursor = cozyPerformanceIndexAt(index, time);
    // Prefix ends also handle a deliberate same-singer overlap without losing a hold.
    while (cursor >= 0 && cozyPerformanceEndPrefixes[index][cursor] > time) {
        if (notes[cursor].endMs > time) return notes[cursor];
        cursor--;
    }
    return null;
}

var cozyPerformanceFallback = [null, null];

function cozyPerformanceRelease(index, time) {
    var notes = cozyPerformanceLines[index];
    var cursor = cozyPerformanceIndexAt(index, time);
    if (cursor < 0) return null;
    var note = notes[cursor];
    if (time < note.endMs) return null;
    var holdMs = 220.0;
    if (cursor + 1 < notes.length && notes[cursor + 1].startMs - note.endMs <= 360.0) {
        holdMs = notes[cursor + 1].startMs - note.endMs;
    }
    return time - note.endMs < holdMs ? note : null;
}

function cozyIsSingerInPhrase(index, time) {
    if (cozyPerformanceActive[index] != null) return true;
    var notes = cozyPerformanceLines[index];
    var cursor = cozyPerformanceIndexAt(index, time);
    if (cursor < 0) return false;
    var prev = notes[cursor];
    if (time - prev.endMs < 240.0) return true;
    if (cursor + 1 < notes.length && notes[cursor + 1].startMs - prev.endMs <= 420.0) return true;
    return false;
}

function cozyPerformanceStateAt(time) {
    var states = cozyPerformanceData.states;
    var left = 0;
    var right = states.length;
    while (left < right) {
        var middle = Std.int((left + right) / 2);
        if (states[middle].startMs <= time) left = middle + 1;
        else right = middle;
    }
    var state = left > 0 ? states[left - 1] : null;
    return state != null && time < state.endMs ? state.state : "INSTRUMENTAL";
}

function cozyPerformanceReaction(index, time) {
    if (cozyPerformanceData.visualEvents == null) return null;
    var singer = index == 0 ? "lila" : "bf";
    var chosen = null;
    for (cue in cozyPerformanceData.visualEvents)
        if (cue.singer == singer && cue.timeMs <= time && time < cue.timeMs + cue.durationMs)
            chosen = cue;
    return chosen;
}

function cozyPerformanceSeek() {
    for (motion in cozyBodyMotion) cozyMotionReset(motion);
    cozyPerformancePoseKeys = ["", ""];
    cozyPerformanceSpecialUntil = [-1.0, -1.0];
    cozyPerformanceFallback = [null, null];
    cozyPerformanceLastMiss = -1.0;
    cozyPerformancePreviousTime = -1.0;
}

function cozyDefaultHitAnimation(event) {
    if (!cozyPerformanceReady || event.note == null) return;
    var ordinary = event.noteType == null || event.noteType == "";
    var time = cozyAudioTime();
    if (ordinary) {
        // Do not cancel the note event: score, health, glow and splash remain native.
        event.preventAnim();
        for (index in 0...2) {
            var character = index == 0 ? dad : boyfriend;
            if (event.characters != null && event.characters.contains(character) && cozyActivePerformanceEvent(index, time) == null) {
                var hold = event.note.sustainLength != null && event.note.sustainLength > 160 ? event.note.sustainLength : 160.0;
                cozyPerformanceFallback[index] = {id: "hit-" + index + "-" + Std.int(time), direction: event.direction, startMs: time, endMs: time + hold};
            }
        }
    } else {
        for (index in 0...2) {
            var character = index == 0 ? dad : boyfriend;
            if (event.characters.contains(character)) {
                var active = cozyActivePerformanceEvent(index, time);
                cozyPerformanceSpecialUntil[index] = active == null ? time + 180 : active.endMs;
            }
        }
    }
}

function cozyPerformanceMiss(event) {
    event.muteVocals = false;
    cozyPerformanceLastMiss = cozyAudioTime();
    cozyPerformanceMissDirection = event.direction;
}

function cozyPerformancePose(character, index, animationName, key, phaseMs, rebuild, cycleMs = 0.0) {
    if (character == null || !character.hasAnimation(animationName)) animationName = "idle";
    if (character == null || !character.hasAnimation(animationName)) return;
    var animation = character.animation.getByName(animationName);
    var frame = animation == null ? 0 : Std.int(Math.min(animation.numFrames - 1, Math.max(0, phaseMs) / 1000 * animation.frameRate));
    if (animation != null && cycleMs > 0)
        frame = Std.int((Math.max(0, phaseMs) % cycleMs) / cycleMs * animation.numFrames);
    if (animation != null && cycleMs < 0 && phaseMs > 140 && animation.numFrames > 2) {
        if (animation.numFrames >= 10) {
            // Lila's 14-frame singing animations have open-mouth hold in frames 3..6 and settle in 8..13.
            // Oscillate gently across 3..6 during sustains so she never snaps from frame 13 back to frame 1.
            var lilaHold = [3, 4, 5, 6, 5, 4];
            var lilaIdx = Std.int(((phaseMs - 140) % -cycleMs) / -cycleMs * lilaHold.length);
            frame = lilaHold[lilaIdx % lilaHold.length];
        } else {
            var bfHold = [1, 2, 3, 2];
            var bfIdx = Std.int(((phaseMs - 140) % -cycleMs) / -cycleMs * bfHold.length);
            frame = bfHold[bfIdx % bfHold.length];
        }
    }
    if (rebuild || cozyPerformancePoseKeys[index] != key || character.getAnimName() != animationName) {
        character.playAnim(animationName, true, "LOCK", false, frame);
        cozyPerformancePoseKeys[index] = key;
    }
    // The audio phase selects the frame. A finished one-shot must not freeze a
    // two-beat dance, and continuing a sustain must not call playAnim each frame.
    character.animation.pause();
    if (character.animation.curAnim != null) character.animation.curAnim.curFrame = frame;
}

function cozyUpdatePerformance(elapsed = 0.0166667) {
    if (!cozyPerformanceReady || inCutscene || startingSong || paused || endingSong) return;
    var time = Math.max(0, cozyAudioTime());
    var rebuild = cozyPerformancePreviousTime < 0 || time < cozyPerformancePreviousTime - .5 || time > cozyPerformancePreviousTime + 500;
    if (rebuild) {
        for (motion in cozyBodyMotion) cozyMotionReset(motion);
        cozyPerformanceSpecialUntil = [-1.0, -1.0];
        cozyPerformanceFallback = [null, null];
        cozyPerformanceLastMiss = -1.0;
    }
    cozyPerformancePreviousTime = time;
    cozyPerformanceTime = time;
    cozyCinemaUpdate(time);
    cozyVocalState = cozyPerformanceStateAt(time);
    cozyPerformanceActive = [cozyActivePerformanceEvent(0, time), cozyActivePerformanceEvent(1, time)];
    for (index in 0...2) {
        if (cozyPerformanceActive[index] == null && cozyPerformanceFallback[index] != null) {
            if (time < cozyPerformanceFallback[index].endMs && time >= cozyPerformanceFallback[index].startMs)
                cozyPerformanceActive[index] = cozyPerformanceFallback[index];
            else
                cozyPerformanceFallback[index] = null;
        }
    }
    var beatMs = 60000 / SONG.meta.bpm;
    var beat = Std.int(Math.floor(time / beatMs));
    for (index in 0...2) {
        var character = index == 0 ? dad : boyfriend;
        if (character != null) character.danceOnBeat = false;
        var dancePeriod = beatMs * 2;
        var danceBeat = Std.int(Math.floor(time / dancePeriod));
        var note = cozyPerformanceActive[index];
        if (cozyPerformanceSpecialUntil[index] > time && note == null) {
            cozyPerformanceModes[index] = "SPECIAL";
            cozyMotionReset(cozyBodyMotion[index]);
            continue;
        }
        if (note != null) {
            cozyPerformanceModes[index] = note.endMs - note.startMs >= 290 && time - note.startMs >= 120 ? "SUSTAINING" : "SINGING";
            var name = ["singLEFT", "singDOWN", "singUP", "singRIGHT"][note.direction];
            cozyPerformancePose(character, index, name, "vocal/" + note.id, time - note.startMs, rebuild,
                cozyPerformanceModes[index] == "SUSTAINING" ? -beatMs : 0);
        } else if (cozyPerformanceRelease(index, time) != null) {
            var released = cozyPerformanceRelease(index, time);
            cozyPerformanceModes[index] = "RELEASE";
            var name = ["singLEFT", "singDOWN", "singUP", "singRIGHT"][released.direction];
            var releasePhase = index == 0 ? 260.0 + (time - released.endMs) * 1.15 : 180.0 + (time - released.endMs) * 1.2;
            cozyPerformancePose(character, index, name, "vocal/" + released.id, releasePhase, rebuild);
        } else if (index == 1 && cozyPerformanceLastMiss >= 0 && time - cozyPerformanceLastMiss < 180) {
            cozyPerformanceModes[index] = "MISS";
            var name = ["singLEFTmiss", "singDOWNmiss", "singUPmiss", "singRIGHTmiss"][cozyPerformanceMissDirection];
            cozyPerformancePose(character, index, name, "miss/" + cozyPerformanceLastMiss, time - cozyPerformanceLastMiss, rebuild);
        } else if (cozyCinemaPose(index, time) != null) {
            var cue = cozyCinemaPose(index, time);
            cozyPerformanceModes[index] = "CINEMA";
            cozyPerformancePose(character, index, cue.animation, "cinema/" + cue.id, time - cue.startMs, rebuild);
        } else if (cozyEffects && cozyPerformanceReaction(index, time) != null) {
            var cue = cozyPerformanceReaction(index, time);
            cozyPerformanceModes[index] = "REACTING";
            cozyPerformancePose(character, index, cue.animation, "reaction/" + cue.id, time - cue.timeMs, rebuild);
        } else if (cozyIsSingerInPhrase(1 - index, time)) {
            var dancing = index == 0 && cozyLilaDanceReady && cozyEffects && beat % 8 >= 4;
            cozyPerformanceModes[index] = dancing ? "DANCING" : "LISTENING";
            var name = dancing ? (danceBeat % 2 == 0 ? "cozyDanceLeft" : "cozyDanceRight")
                : character != null && character.hasAnimation("cozyListen") ? "cozyListen" : "idle";
            cozyPerformancePose(character, index, name, dancing ? "answer-dance/" + danceBeat : "listen",
                dancing ? time - danceBeat * dancePeriod : time, rebuild, dancing ? dancePeriod : beatMs * 4);
        } else {
            cozyPerformanceModes[index] = cozyEffects ? "DANCING" : "RESTING";
            var name = index == 0 && cozyLilaDanceReady && cozyEffects ? (danceBeat % 2 == 0 ? "cozyDanceLeft" : "cozyDanceRight") : "idle";
            if (index == 1 && cozyEffects && character != null && character.hasAnimation("cozyDanceLeft"))
                name = danceBeat % 2 == 0 ? "cozyDanceLeft" : "cozyDanceRight";
            cozyPerformancePose(character, index, name, "rest/" + danceBeat, time - danceBeat * dancePeriod, rebuild, dancePeriod);
        }
        var activeMotionNote = cozyPerformanceActive[index];
        var motionMode = cozyPerformanceModes[index];
        if (activeMotionNote == null && motionMode == "RELEASE") activeMotionNote = cozyPerformanceRelease(index, time);
        var motionDirection = activeMotionNote == null ? cozyPerformanceMissDirection : activeMotionNote.direction;
        var motionKey = motionMode == "MISS" ? "miss/" + cozyPerformanceLastMiss : activeMotionNote == null ? cozyPerformancePoseKeys[index] : activeMotionNote.id;
        var motionPhase = activeMotionNote == null ? Math.max(0, time - cozyPerformanceLastMiss) : time - activeMotionNote.startMs;
        if (motionMode == "CINEMA") {
            motionPhase = time - cozyCinemaPose(index, time).startMs;
            motionMode = "GESTURE";
        }
        if (motionMode == "REACTING") {
            motionPhase = time - cozyPerformanceReaction(index, time).timeMs;
            motionMode = "GESTURE";
        }
        cozyMotionStep(cozyBodyMotion[index], elapsed, time / 1000, time / beatMs, motionMode,
            motionDirection, motionKey, motionPhase, 0, !cozyEffects);
    }
}

function cozyDestroyMotion() {
    for (motion in cozyBodyMotion) cozyMotionReset(motion);
    cozyBodyMotion = [null, null];
}

function cozyPerformanceSnapshot() {
    return {ready:cozyPerformanceReady,timeMs:cozyPerformanceTime,state:cozyVocalState,
        modes:{lila:cozyPerformanceModes[0],bf:cozyPerformanceModes[1]},
        activeEventIds:{lila:cozyPerformanceActive[0] == null ? null : cozyPerformanceActive[0].id,
            bf:cozyPerformanceActive[1] == null ? null : cozyPerformanceActive[1].id},
        poses:{lila:dad.getAnimName(),bf:boyfriend.getAnimName()},
        frames:{lila:dad.animation.curAnim == null ? -1 : dad.animation.curAnim.curFrame,
            bf:boyfriend.animation.curAnim == null ? -1 : boyfriend.animation.curAnim.curFrame},
        positions:{lila:[dad.x,dad.y],bf:[boyfriend.x,boyfriend.y]},
        lilaDance:cozyLilaDanceReady,muteVocalsOnMiss:muteVocalsOnMiss};
}
