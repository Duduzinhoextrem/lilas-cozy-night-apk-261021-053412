// Reusable, legible paper insert. Artwork and text are independent of character drawings.
function cozyPaperCreate(x, y, scale = 1.0) {
    var p = {objects:[], rows:[], doodle:null, note:null};
    var bg = new FlxSprite(x, y).loadGraphic(Paths.image("props/v3-paper"));
    bg.scale.set(scale,scale); bg.updateHitbox(); add(bg); p.objects.push(bg);
    var title = cozyText(x+40*scale,y+35*scale,450*scale,"PLANOS PRA HOJE",Std.int(28*scale),0xFF634349,true);
    p.objects.push(title);
    var sub = cozyText(x+40*scale,y+78*scale,450*scale,"uma noite, sem pressa",Std.int(19*scale),0xFF87656A);
    p.objects.push(sub);
    for (i in 0...4) {
        var row = cozyText(x+40*scale,y+(130+i*59)*scale,450*scale,"",Std.int(25*scale),0xFF634349);
        p.rows.push(row); p.objects.push(row);
    }
    var steps = new FlxSprite(x+48*scale,y+377*scale).loadGraphic(Paths.image("props/v3-footsteps"));
    steps.scale.set(.7*scale,.7*scale);steps.updateHitbox();add(steps);p.doodle=steps;p.objects.push(steps);
    p.note=cozyText(x+97*scale,y+380*scale,370*scale,"",Std.int(20*scale),0xFF946275);p.objects.push(p.note);
    cozyPaperState(p,0,false,"");
    return p;
}
function cozyPaperState(p, completed, doodle, last) {
    var labels=["Uma música em casa","Jardim das sakuras","Lanternas do festival",last==null || last.length==0 ? "________________" : last];
    for(i in 0...4)p.rows[i].text=(i<completed ? "[x]  " : "[ ]  ")+labels[i];
    p.doodle.visible=doodle;
    p.note.text=doodle ? "+ o passo torto!" : "";
}
function cozyPaperVisible(p, visible) { for(o in p.objects)o.visible=visible; }
