// Additive presentation only. Audio, notes, hit windows and score never use this clock.
// Exact critically damped integration avoids frame-rate-dependent lerp and drift.
function cozyMotionAxis() { return {p: 0.0, v: 0.0}; }

function cozyMotionDamp(axis, target, omega, elapsed) {
    var delta = axis.p - target;
    var spring = axis.v + omega * delta;
    var decay = Math.exp(-omega * elapsed);
    axis.p = target + (delta + spring * elapsed) * decay;
    axis.v = (axis.v - omega * spring * elapsed) * decay;
}

function cozyMotionCreate(actor, bf, portrait = false) {
    return {actor: actor, bf: bf, portrait: portrait,
        sx: actor.scale.x, sy: actor.scale.y, angle: actor.angle,
        ex: portrait ? 0 : actor.extraOffset.x, ey: portrait ? 0 : actor.extraOffset.y,
        footX: bf ? 256 : 213, footY: bf ? 488 : 871,
        lean: cozyMotionAxis(), weight: cozyMotionAxis(), compression: cozyMotionAxis(),
        event: "", pulse: 0.0, appliedX: 0.0, appliedY: 0.0};
}

function cozyMotionRestore(motion) {
    if (motion == null || motion.actor == null) return;
    var actor = motion.actor;
    // Native destruction can release sprite points before the script destroy hook.
    if (actor.scale == null || actor.origin == null) return;
    actor.scale.set(motion.sx, motion.sy);
    actor.angle = motion.angle;
    if (motion.portrait) {
        actor.x -= motion.appliedX;
        actor.y -= motion.appliedY;
    } else actor.extraOffset.set(motion.ex, motion.ey);
    motion.appliedX = motion.appliedY = 0;
}

function cozyMotionReset(motion) {
    if (motion == null) return;
    cozyMotionRestore(motion);
    motion.lean.p = motion.lean.v = 0;
    motion.weight.p = motion.weight.v = 0;
    motion.compression.p = motion.compression.v = 0;
    motion.event = "";
    motion.pulse = 0;
}

function cozyMotionStep(motion, elapsed, time, beat, mode, direction, eventId, phaseMs, moving = 0.0, reduced = false) {
    if (motion == null || motion.actor == null) return;
    if (motion.actor.scale == null || motion.actor.origin == null) return;
    // Remove exactly the previous additive transform, not the actor's authored position.
    cozyMotionRestore(motion);
    if (reduced) { cozyMotionReset(motion); return; }
    var dt = Math.max(0, Math.min(.1, elapsed));
    var actor = motion.actor;
    var bf = motion.bf;
    var breath = Math.sin(time * 1.55 + (bf ? .7 : 2.1));
    var beatPhase = beat - Math.floor(beat);
    var beatPulse = Math.pow(Math.max(0, 1 - beatPhase / .36), 2);
    var singing = mode == "SINGING" || mode == "SUSTAINING" || mode == "RELEASE";
    var talking = mode == "TALKING" || mode == "GESTURE";
    var seated = mode == "SEATED";
    var targetLean = .16 * Math.sin(beat * Math.PI + (bf ? 0 : .65));
    var targetWeight = .32 * Math.sin(beat * Math.PI + (bf ? .6 : 1.8));
    var targetCompression = bf ? .0016 * breath + .0022 * beatPulse : 0;

    if (eventId != motion.event) {
        motion.event = eventId;
        motion.pulse = 1;
    }
    motion.pulse *= Math.exp(-dt * 12);
    if (singing) {
        var attack = Math.exp(-Math.max(0, phaseMs) / 115);
        targetLean = (direction == 0 ? -.6 : direction == 3 ? .6 : direction == 1 ? .16 : -.12) * (bf ? 1 : .45);
        targetLean += (direction == 0 ? -.32 : direction == 3 ? .32 : 0) * attack;
        targetWeight = (direction == 0 ? -.65 : direction == 3 ? .65 : 0) * (bf ? 1 : .6);
        targetCompression = bf ? .003 * breath + .005 * attack + (direction == 1 ? .003 : 0) : 0;
    } else if (talking) {
        // Anticipate, deliver, then settle; no continuous exaggerated rocking.
        var anticipation = phaseMs < 95 ? -1 : Math.exp(-(phaseMs - 95) / 220);
        targetLean = (bf ? -.38 : .22) * anticipation;
        targetWeight = (bf ? -.7 : .4) * anticipation;
        targetCompression = bf ? .003 * breath + .005 * Math.max(0, anticipation) : 0;
    } else if (mode == "MISS") {
        targetLean = (direction == 0 ? .65 : -.65) * motion.pulse;
        targetCompression = bf ? .006 * motion.pulse : 0;
    } else if (mode == "LISTENING") {
        targetLean *= .55;
        targetWeight *= .5;
        targetCompression *= .65;
    }
    if (Math.abs(moving) > .01) {
        targetLean = (moving > 0 ? -.45 : .45);
        targetWeight += .55 * Math.sin(time * Math.PI * 4);
        targetCompression = bf ? .0035 * Math.sin(time * Math.PI * 4) : 0;
    }
    if (seated) { targetLean *= .25; targetWeight = 0; targetCompression = bf ? .001 * breath : 0; }

    cozyMotionDamp(motion.lean, targetLean, 20, dt);
    cozyMotionDamp(motion.weight, targetWeight, 18, dt);
    cozyMotionDamp(motion.compression, targetCompression, 22, dt);
    var lean = Math.max(-1.1, Math.min(1.1, motion.lean.p));
    var compression = Math.max(-.009, Math.min(.012, motion.compression.p));
    // Senko's original drawing is not scaled/deformed. Only BF uses tiny elastic recovery.
    var newScaleX = motion.sx * (bf ? 1 + compression * .35 : 1);
    var newScaleY = motion.sy * (bf ? 1 - compression : 1);
    var radians = lean * Math.PI / 180;
    var ax = motion.footX - actor.origin.x;
    var ay = motion.footY - actor.origin.y;
    var footX = ax * newScaleX * Math.cos(radians) - ay * newScaleY * Math.sin(radians);
    var footY = ax * newScaleX * Math.sin(radians) + ay * newScaleY * Math.cos(radians);
    var dx = ax * motion.sx - footX + Math.max(-1.2, Math.min(1.2, motion.weight.p));
    var dy = ay * motion.sy - footY;
    actor.scale.set(newScaleX, newScaleY);
    actor.angle = motion.angle + lean;
    if (motion.portrait) { actor.x += dx; actor.y += dy; }
    else actor.extraOffset.set(motion.ex + dx, motion.ey + dy);
    motion.appliedX = dx;
    motion.appliedY = dy;
}
