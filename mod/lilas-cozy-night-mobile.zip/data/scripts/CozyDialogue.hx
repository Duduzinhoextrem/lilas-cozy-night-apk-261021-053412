import data.scripts.CozyCinema;
function create() {
    if (!PlayState.isStoryMode) { close(); return; }
    var project = cozyProject();
    var index = 0;
    for (i in 0...project.songs.length) if (project.songs[i].id == PlayState.SONG.meta.name) index = i;
    cinemaStart(index, false, function() { close(); });
}
function update(elapsed) { cinemaUpdate(elapsed); }
function destroy() { cinemaClear(true); }
