import data.scripts.CozyMobile;
import funkin.backend.assets.MultiFramesCollection;
var cozyPortraitOffsets = [];

// Shared presentation helpers. Content, gameplay and cutscenes use the same fonts.
function cozyText(x, y, width, value, size = 24, color = 0xFFFFF3DD, heading = false) {
    if (size == null) size = 24;
    if (color == null) color = 0xFFFFF3DD;
    var field = new FlxText(x, y, width, value, size);
    field.setFormat(Paths.font(heading ? "LilitaOne-Regular.ttf" : "AtkinsonHyperlegible-Regular.ttf"), size, color, "left");
    field.antialiasing = true;
    add(field);
    return field;
}

function cozyBox(x, y, width, height, color, alpha = 1.0) {
    if (alpha == null) alpha = 1.0;
    var box = new FlxSprite(x, y).makeGraphic(width, height, color);
    box.alpha = alpha;
    add(box);
    return box;
}

function cozyBackground(stageName) {
    var image = new FlxSprite().loadGraphic(Paths.image(cozyStageImage(stageName)));
    // Cover without stretching; center the small overscan outside the viewport.
    var ratio = Math.max(1280 / image.width, 720 / image.height);
    image.scale.set(ratio, ratio);
    image.updateHitbox();
    image.screenCenter();
    add(image);
    return image;
}

function cozyStageImage(stageName) {
    var project = cozyProject();
    var path = "stages/night/" + stageName;
    return cozyUseNewArt() && Assets.exists(Paths.image(path)) ? path : "stages/" + stageName;
}

function cozyUseNewArt() {
    var project = cozyProject();
    return project.presentation != null && project.presentation.newArt == true && FlxG.save.data.cozyOriginalArt != true;
}

function cozyAmbient(stageName, world = false) {
    var objects = [];
    if (!cozyUseNewArt()) return objects;
    var prop = stageName == "cozy-room" ? "curtain" : stageName == "sakura-garden" ? "sakura" : stageName == "kawaii-festival" ? "lantern" : "leaves";
    var path = Paths.image("props/" + prop);
    if (!Assets.exists(path)) return objects;
    var image = new FlxSprite(world ? -190 : 18, world ? -80 : 60).loadGraphic(path);
    image.setGraphicSize(0, prop == "lantern" ? 155 : 230);
    image.updateHitbox();
    image.antialiasing = true;
    image.scrollFactor.set(world ? 1.06 : 0, world ? 1.06 : 0);
    image.origin.set(image.width / 2 / image.scale.x, 0);
    add(image);
    objects.push(image);
    return objects;
}

function cozyPortrait(character, x, y, height) {
    var image = new FlxSprite(x, y);
    var project = cozyProject();
    var visual = project.characterVisuals == null ? null : Reflect.field(project.characterVisuals, character);
    if (character == "bf" && cozyUseNewArt() && Assets.exists(Paths.image("characters/bf-night"))) visual = "bf-night";
    image.frames = Paths.getSparrowAtlas("characters/" + (visual == null ? character : visual));
    image.animation.addByPrefix("idle", character == "lila" ? "idle" : "BF idle dance", visual == "bf-night" ? 12 : 24, true);
    if (character == "bf") {
        image.animation.addByPrefix("hey", visual == "bf-night" ? "cozyEncourage_" : visual == "bf-cozy" ? "cozyEncourage" : "BF HEY", 12, false);
        if (visual == "bf-cozy") {
            for (pose in ["Listen", "Encourage", "Surprise", "Celebrate", "Interact", "GameOver"])
                image.animation.addByPrefix("cozy" + pose, "cozy" + pose, 12, false);
        }
        if (visual == "bf-night") {
            for (pose in ["idleCalm", "idleNervous", "listen", "smile", "shy", "surprised", "laugh", "lookAway", "lookAtLila", "showList", "hideList", "holdMicrophone", "putAwayMicrophone", "encourage", "celebrate", "fistBump", "sit", "wave", "walk", "sitListen", "sitSmile", "sitLaugh", "sitLook", "cozyListen", "cozyEncourage", "cozySurprise", "cozyCelebrate", "cozyInteract", "cozyGameOver"])
                image.animation.addByPrefix(pose, pose + "_", pose == "listen" || pose == "cozyListen" ? 6 : 12, pose == "listen" || pose == "cozyListen" || pose == "walk");
        } else {
            var names = ["idleCalm", "idleNervous", "listen", "smile", "shy", "surprised", "laugh", "lookAway", "lookAtLila", "showList", "hideList", "holdMicrophone", "putAwayMicrophone", "encourage", "celebrate", "fistBump", "sit", "wave", "walk"];
            var prefixes = ["BF idle dance", "cozySurprise", "cozyListen", "BF idle dance", "cozyListen", "cozySurprise", "cozyCelebrate", "cozyListen", "cozyListen", "cozyInteract", "cozyListen", "cozyEncourage", "cozyListen", "cozyEncourage", "cozyCelebrate", "cozyInteract", "cozyListen", "cozyEncourage", "BF idle dance"];
            for (i in 0...names.length) image.animation.addByPrefix(names[i], prefixes[i], 12, false);
            if(visual=="bf-cozy")for(pose in ["sitListen","sitSmile","sitLaugh","sitLook"])image.animation.addByPrefix(pose,"cozyGameOver",12,false);
        }
    } else if (character == "lila") {
        // Existing Senko singing poses only; no altered or recolored character art.
        image.animation.addByPrefix("look", "left", 24, false);
        var graphic = FlxG.bitmap.add("flixel/images/logo/default.png", false, "cozy/lila-cinema-frames-v3");
        var combined = MultiFramesCollection.findFrame(graphic);
        if (combined == null) {
            combined = new MultiFramesCollection(graphic);
            var atlases=[image.frames,Paths.getSparrowAtlas("characters/lila-dance")];
            if(cozyUseNewArt() && Assets.exists(Paths.image("characters/lila-story-v3")))atlases.push(Paths.getSparrowAtlas("characters/lila-story-v3"));
            for (atlas in atlases) {
                var first = combined.frames.length;
                combined.addFrames(atlas);
                for (i in first...combined.frames.length) {
                    var copy = combined.frames[i].copyTo();
                    if(copy.sourceSize.x<900) {
                        copy.sourceSize.set(900,1000);
                        copy.offset.x+=200;copy.offset.y+=100;
                    }
                    combined.frames[i] = copy;
                    combined.framesHash.set(copy.name, copy);
                }
            }
        }
        image.frames = combined;
        image.animation.addByPrefix("idle", "idle", 24, true);
        image.animation.addByPrefix("look", "left", 24, false);
        image.animation.addByPrefix("danceLeft", "danceleft", 24, false);
        image.animation.addByPrefix("danceRight", "danceright", 24, false);
        if(cozyUseNewArt() && Assets.exists(Paths.image("characters/lila-story-v3"))) {
            image.animation.addByPrefix("invite","storyInvite_",8,false);
            image.animation.addByPrefix("laugh","storyLaugh_",8,false);
        } else {
            image.animation.addByPrefix("invite","idle",24,false);
            image.animation.addByPrefix("laugh","idle",24,false);
        }
        // Original dance drawings supply restrained steps while travelling.
        image.animation.addByPrefix("walk","danceleft",10,true);
    }
    image.animation.play("idle");
    image.setGraphicSize(0, character=="lila" ? height*1000/872 : height);
    image.updateHitbox();
    image.antialiasing = true;
    if(character=="lila"){image.x-=200*image.scale.x;image.y-=100*image.scale.y;}
    cozyPortraitOffsets.push({image: image, x: image.offset.x, y: image.offset.y, lila: character == "lila"});
    if (FlxG.save.data.cozyEffects == false || FlxG.save.data.cozyReducedMotion == true) image.animation.pause();
    add(image);
    return image;
}

function cozyProject() {
    return Json.parse(Assets.getText(Paths.file("data/cozy-project.json")));
}

function cozyCelebrate(x, y, height) {
    var image = new FlxSprite(x, y);
    image.frames = Paths.getSparrowAtlas("characters/lila-dance");
    image.animation.addByPrefix("left", "danceleft", 24, false);
    image.animation.addByPrefix("right", "danceright", 24, false);
    image.animation.finishCallback = function(name) { image.animation.play(name == "left" ? "right" : "left"); };
    image.animation.play("left");
    image.setGraphicSize(0, height);
    image.updateHitbox();
    image.antialiasing = true;
    if (FlxG.save.data.cozyEffects == false) image.animation.pause();
    add(image);
    return image;
}

function cozySound(confirm = false) {
    FlxG.sound.play(Paths.sound(confirm ? "menu/confirm" : "menu/scroll"), .35);
}

function cozyPose(image, animation) {
    if (!image.animation.exists(animation)) animation = "idle";
    if (image.animation.curAnim == null || image.animation.curAnim.name != animation) image.animation.play(animation, true);
    for (entry in cozyPortraitOffsets) if (entry.image == image && entry.lila) {
        image.offset.set(entry.x + (animation == "danceLeft" || animation == "walk" ? 77.5 : animation == "danceRight" ? 17.5 : 0),
            entry.y + (animation == "danceLeft" || animation == "walk" ? -23 : animation == "danceRight" ? -33 : 0));
    }
    if (FlxG.save.data.cozyEffects == false || FlxG.save.data.cozyReducedMotion == true) image.animation.pause();
}

