import data.scripts.CozyUi;
import data.scripts.CozyMotion;
import data.scripts.CozyPaper;
import funkin.backend.week.Week;
import funkin.options.OptionsMenu;
import funkin.savedata.FunkinSave;
import funkin.backend.system.framerate.Framerate;

var page = "home";
var selected = 0;
var diffIndex = 1;
var elapsedMenu = 0.0;
var inputAge = 0.0;
var leaving = false;
var practice = false;
var creditPage = 0;
var introStep = 0;
var project;
var titleText;
var bodyText;
var noteText;
var footer;
var rows = [];
var marks = [];
var preview;
var portraitLila;
var portraitBf;
var difficultyText;
var recordText;
var difficultyNames = ["EASY", "NORMAL", "HARD"];
var homeLabels = ["História", "Freeplay", "Opções", "Extras", "Créditos"];
var homeDescriptions = ["Quatro lugares. Uma noite entre amigos.", "Escolha uma música e entre no ritmo.", "Deixe a noite do seu jeito.", "Uma mensagem pra Lila e os controles.", "Quem deu voz, cor e música à noite."];
var optionLabels = ["Rolagem para baixo", "Efeitos de cenário", "Modo de exibição", "Volume", "Controles e mais opções"];

var menuSceneCamera;
var menuUiCamera;
var menuMotion=[];
var menuWorld=[];
var menuPaper;
var menuRecord;
var menuCards=[];
var menuCardLabels=[];
var menuPhase=-1;
var menuSub;
var menuRoute;
var menuBodyPanel;
function menuUi(object){object.cameras=[menuUiCamera];return object;}
function menuWorldObject(object){object.cameras=[menuSceneCamera];menuWorld.push(object);return object;}
function create() {
    if (Framerate.instance != null) Framerate.instance.visible=false;
    project=cozyProject();
    if(FlxG.save.data.cozyDifficulty!=null)diffIndex=FlxG.save.data.cozyDifficulty;
    if(diffIndex<0 || diffIndex>2)diffIndex=1;
    practice=FlxG.save.data.cozyPractice==true;
    page=data!=null && data.page!=null ? data.page : "home";
    if(page=="intro")page="story";
    if(page=="freeplay" && FlxG.save.data.cozySongIndex!=null)selected=FlxG.save.data.cozySongIndex;
    menuSceneCamera=new FlxCamera();FlxG.cameras.add(menuSceneCamera,false);
    menuUiCamera=new FlxCamera();menuUiCamera.bgColor=0;FlxG.cameras.add(menuUiCamera,false);
    cameras=[menuSceneCamera];
    menuWorldObject(cozyBackground("cozy-room"));
    for(o in cozyAmbient("cozy-room"))menuWorldObject(o);
    portraitLila=menuWorldObject(cozyPortrait("lila",705,620-871*(450/872),450));
    portraitBf=menuWorldObject(cozyPortrait("bf",905,620-488*(390/512),390));
    menuMotion=[cozyMotionCreate(portraitLila,false,true),cozyMotionCreate(portraitBf,true,true)];
    menuMotion[0].footX=413;menuMotion[0].footY=971;
    var table=menuWorldObject(new FlxSprite(452,492).loadGraphic(Paths.image("props/v3-table")));add(table);
    menuPaper=cozyPaperCreate(472,354,.32);for(o in menuPaper.objects)menuWorldObject(o);
    menuRecord=menuWorldObject(new FlxSprite(604,467).loadGraphic(Paths.image("props/v3-record")));menuRecord.setGraphicSize(70,70);menuRecord.updateHitbox();add(menuRecord);
    var veil=new FlxSprite().loadGraphic(Paths.image("props/v3-veil"));add(veil);menuUi(veil);
    titleText=menuUi(cozyText(60,36,640,"LILA'S\nCOZY NIGHT",54,0xFFFFD8A5,true));
    menuSub=menuUi(cozyText(64,168,700,"Alguns momentos merecem ficar.",20,0xFFF5B3C7));
    for(i in 0...5) {
        marks.push(menuUi(cozyBox(60,242+i*59,365,49,0xFFF1A96E,.1)));
        rows.push(menuUi(cozyText(78,248+i*59,550,"",28,0xFFFFF3DD,true)));
    }
    preview=new FlxSprite(720,270);add(preview);menuUi(preview);
    menuBodyPanel=menuUi(cozyBox(716,224,516,430,0xFF211B2D,.9));
    bodyText=menuUi(cozyText(732,234,470,"",25));
    noteText=menuUi(cozyText(64,588,595,"",21,0xFFF2CDCB));
    difficultyText=menuUi(cozyText(736,552,480,"",28,0xFFFFD8A5,true));
    recordText=menuUi(cozyText(736,594,480,"",20,0xFFF1D9CF));
    menuRoute=menuUi(cozyText(66,208,1150,"",22,0xFFFFD8A5,true));
    for(i in 0...4) {
        var card=new FlxSprite(50+i*300,275).loadGraphic(Paths.image(cozyStageImage(project.songs[i].stage)));
        card.setGraphicSize(270,0);card.updateHitbox();add(card);menuUi(card);menuCards.push(card);
        menuCardLabels.push(menuUi(cozyText(54+i*300,465,278,(i+1)+". "+project.songs[i].chapterTitle,22,0xFFFFD8A5,true)));
    }
    menuUi(cozyBox(0,678,1280,42,0xFF221827,.92));
    footer=menuUi(cozyText(48,688,1190,"",17,0xFFF2D7CC));
    if(FlxG.sound.music==null || !FlxG.sound.music.playing)FlxG.sound.playMusic(Paths.music("cozy-menu"),.5,true);
    refresh();cozyMobileSetup(true);trace("COZY menu ready: "+page);
}

function refresh() {
    inputAge = 0;
    bodyText.x=732;bodyText.y=234;bodyText.fieldWidth=470;bodyText.size=25;
    difficultyText.x=736;difficultyText.y=552;recordText.x=736;recordText.y=594;
    noteText.y=588;
    titleText.text=page=="home" ? "LILA'S\nCOZY NIGHT" : page=="story" ? "UMA NOITE\nENTRE AMIGOS" : page=="freeplay" ? "SÓ MAIS\nUMA MÚSICA" : page=="options" ? "DO SEU\nJEITO" : page=="credits" ? "QUEM FEZ\nESSA NOITE" : "MAIS UM\nPOUQUINHO";
    menuSub.text=page=="home" ? "Alguns momentos merecem ficar." : "Lila’s Cozy Night";
    for(o in menuWorld)o.visible=page=="home";
    // Keep the room background visible in every page.
    menuWorld[0].visible=true;
    menuPaper.doodle.visible=false;
    for(o in menuCards)o.visible=page=="story";
    for(o in menuCardLabels)o.visible=page=="story";
    menuRoute.visible=page=="story";
    menuBodyPanel.visible=page=="options" || page=="extras" || page=="credits";
    if(page=="credits" || page=="extras"){menuBodyPanel.makeGraphic(1160,430,0xFF211B2D);menuBodyPanel.x=60;}
    else {menuBodyPanel.makeGraphic(516,430,0xFF211B2D);menuBodyPanel.x=716;}
    var isList = page == "home" || page == "freeplay" || page == "options";
    portraitLila.visible = portraitBf.visible = page == "home";
    preview.visible = false;
    bodyText.visible = page != "home";
    bodyText.text = "";
    difficultyText.text = "";
    recordText.text = "";
    for (i in 0...5) {
        rows[i].visible = marks[i].visible = isList;
        marks[i].alpha = i == selected ? .88 : 0;
        rows[i].color = i == selected ? 0xFF352036 : 0xFFFFEFDC;
        rows[i].text = "";
    }
    footer.text = "SETAS escolher   ·   A confirmar   ·   B voltar";
    noteText.text = "";
    if (page == "home") {
        for (i in 0...5) rows[i].text = (i == selected ? ">  " : "   ") + homeLabels[i];
        noteText.text = homeDescriptions[selected];
    } else if (page == "freeplay") {
        for (i in 0...4) rows[i].text = (i + 1) + ".  " + project.songs[i].title;
        rows[4].visible = marks[4].visible = false;
        var song = project.songs[selected];
        preview.loadGraphic(Paths.image(cozyStageImage(song.stage)));
        preview.setGraphicSize(450, 0);
        preview.updateHitbox();
        preview.visible = true;
        difficultyText.text = "< " + difficultyNames[diffIndex] + " >";
        var stats = FlxG.save.data.cozyResults;
        var key = song.id + "_" + project.difficulties[diffIndex] + (practice ? "_practice" : "_normal");
        var previous = stats == null ? null : Reflect.field(stats, key);
        recordText.text = previous == null ? "Sem recorde ainda. Bora inaugurar?" : (practice ? "Última prática: " : "Seu recorde: ") + previous.score + "  /  " + previous.accuracy + "%";
        noteText.text = song.artist + "\n" + (practice ? "PRÁTICA: sem derrota e sem recorde." : "Você joga como Boyfriend.");
        footer.text = "SETAS música/dificuldade  ·  X prática  ·  A jogar  ·  B voltar";
    } else if (page == "story") {
        for(o in rows)o.visible=false;for(o in marks)o.visible=false;
        bodyText.text="";
        menuRoute.text="QUARTO   >   JARDIM   >   FESTIVAL   >   TEMPLO";
        difficultyText.x=66;difficultyText.y=534;difficultyText.text="< "+difficultyNames[diffIndex]+" >";
        recordText.x=66;recordText.y=579;recordText.text=practice ? "PRÁTICA · sem derrota e sem recorde" : "Uma lista preparada. Uma noite pra improvisar.";
        noteText.y=625;noteText.text="Quatro músicas · oito cenas · uma lembrança dos dois.";
        footer.text="ESQ / DIR dificuldade   ·   X prática   ·   A começar   ·   B voltar";
    } else if (page == "options") {
        for (i in 0...5) rows[i].text = optionLabels[i];
        bodyText.text = "DO SEU JEITO\n\nRolagem: " + (Options.downscroll ? "para baixo" : "para cima") + "\nEfeitos: " + (FlxG.save.data.cozyEffects == false ? "reduzidos" : "ligados") + "\nTela: " + (FlxG.fullscreen ? "cheia" : "janela") + "\nVolume: " + Math.round(FlxG.sound.volume * 100) + "%\n\nEm Controles e mais opções:\nremapeamento, latência,\naparência e acessibilidade.";
        noteText.text = "A alterna a opção.\nNo volume, use ESQUERDA / DIREITA.\nY: alternar arte nova / original.";
    } else if (page == "extras") {
        bodyText.x = 78;
        bodyText.y = 242;
        bodyText.fieldWidth = 1110;
        bodyText.text = "ALGUNS MOMENTOS MERECEM FICAR.\n\nUma noite entre amigos, com espaço pra improvisar.\nA mensagem pessoal aparece no fim da campanha.\n\nCONTROLES\nToque nas áreas de notas  ·  P: menu de pausa\nNa pausa: continuar, reiniciar ou voltar ao menu\nNas cenas: A completa o texto e avança\nB pula a cena  ·  Jogue com o celular deitado\nEm Freeplay, X liga a prática.";
        bodyText.size = 24;
        footer.text = "B ou A: voltar ao menu  ·  Jogue com o celular deitado";
    } else if (page == "credits") {
        bodyText.x = 78;
        bodyText.y = 238;
        bodyText.fieldWidth = 1110;
        var pages = [
            "AS MÚSICAS\n\nBeathoven — PaperKitty / VS. Kapi. Chart e stems de referência do mod.\nKawaikute Gomen — HoneyWorks / Chuu-tan (Saori Hayami).\nInstrumental fornecido: Yeonggill Lee; alinhado à nova referência FNF.\nPerformance FNF de referência: Typical Silence Suzuka enjoyer.\nLooping the Rooms — rusino feat. Hatsune Miku. MIDI e instrumental Off-Vocal fornecidos pelo usuário.\nDummy Romance — referência fornecida: VocaloidCover 2.2.3.\nComposição e arranjo: créditos ainda em conferência.\n\nGravações originais preservadas na produção.\nEste presente é pessoal, sem publicação ou monetização.",
            "PERSONAGENS E VOZES\n\nSenko — KawaiENA, Sewayaki Kitsune no Senko San / FNF ONESHOT.\nArte e animação: KawaiENA. Página: gamebanana.com/wips/98100.\nLicença declarada: CC BY-NC-ND 4.0. Arte preservada. Uso privado.\nSenko-san é personagem de Rimukoro; direitos dos titulares preservados.\nBoyfriend — Funkin' Crew: PhantomArcade, evilsk8r, Kawai Sprite e equipe.\nVoz BF — NyxTheShield; samples originais Kawai Sprite / cortes GenoX.\nVoz musical da Lila — Natsuki / Doki Doki Takeover (Team TBD).\nBanco Sonnah / SuperStamps. É um timbre escolhido para o mod,\nsem alegar voz original de Senko ou clonagem da voz da Lila.",
            "FEITO PARA ESTA NOITE\n\nConceito, seleção e presente: Dudu / Dudz, para Lila.\nEngine: Codename Crew — Codename Engine 1.0.1 (commit 9757b00).\nIntegração, ferramentas e cenários produzidos com assistência de IA / Codex.\nNovas poses BF, gestos extras Senko, cenários e objetos: image_gen.\nAtlas e integração: Codex. Revisão de aparência e animação humana pendente.\nÁudio: FluidSynth, libsndfile, FFmpeg, NumPy e SciPy.\nFontes: Lilita One (Juan Montoreano) e Atkinson Hyperlegible\n(Braille Institute / Applied Design Works), SIL Open Font License.\n\nObrigado a quem cria arte, músicas e ferramentas para o FNF.\nOs direitos dos recursos continuam com seus autores."
        ];
        bodyText.text = pages[creditPage];
        bodyText.size = 23;
        footer.text = "ESQUERDA / DIREITA: créditos (" + (creditPage + 1) + "/3)   ·   B ou A voltar";
    } else if (page == "intro") {
        bodyText.x = 98;
        bodyText.y = 258;
        bodyText.fieldWidth = 1080;
        bodyText.size = 34;
        var lines = [
            "Uma lista dobrada.\nQuatro músicas separadas com cuidado.",
            "Boyfriend achou que tinha planejado tudo.\nLila ainda não viu o papel.",
            "Alguns momentos merecem ficar.\nOs melhores talvez nem estejam na lista."
        ];
        bodyText.text = lines[introStep];
        footer.text = "A: continuar   ·   B: pular abertura e começar";
    }
}

function openPage(name) {
    FlxG.switchState(new ModState("CozyMenu", {page: name}));
}

function saveChoices() {
    FlxG.save.data.cozyDifficulty = diffIndex;
    FlxG.save.data.cozyPractice = practice;
    FlxG.save.data.cozySongIndex = selected;
    FlxG.save.flush();
}

function launchStory() {
    if (leaving) return;
    leaving = true;
    saveChoices();
    ModState.lastData = {page: "home"};
    PlayState.loadWeek(Week.loadWeek("lilas-cozy-night", false), project.difficulties[diffIndex]);
    FlxG.switchState(new PlayState());
}

function launchFreeplay() {
    if (leaving) return;
    leaving = true;
    saveChoices();
    PlayState.loadSong(project.songs[selected].id, project.difficulties[diffIndex], null, false, false);
    FlxG.switchState(new PlayState());
}

function adjustOption(direction = 1) {
    switch (selected) {
        case 0: Options.downscroll = !Options.downscroll;
        case 1: FlxG.save.data.cozyEffects = FlxG.save.data.cozyEffects == false;
        case 2: FlxG.fullscreen = !FlxG.fullscreen;
        case 3:
            FlxG.sound.volume = Math.max(0, Math.min(1, FlxG.sound.volume + .1 * direction));
            Options.volume = FlxG.sound.volume;
        case 4:
            FlxG.switchState(new OptionsMenu());
            return;
    }
    Options.save();
    FlxG.save.flush();
    refresh();
}

function update(elapsed) {
    elapsedMenu += elapsed;
    inputAge += elapsed;
    var reduced=FlxG.save.data.cozyEffects==false || FlxG.save.data.cozyReducedMotion==true;
    if(page=="home") {
        var phase=Std.int(elapsedMenu/3.5)%5;
        if(phase!=menuPhase && !reduced) {
            menuPhase=phase;
            cozyPose(portraitBf,["listen","smile","encourage","listen","laugh"][phase]);
            cozyPose(portraitLila,["idle","invite","laugh","idle","idle"][phase]);
        }
        for(i in 0...menuMotion.length)cozyMotionStep(menuMotion[i],elapsed,elapsedMenu,elapsedMenu*.6,"LISTENING",0,"menu",0,0,reduced);
        menuRecord.angle=reduced ? 0 : Math.sin(elapsedMenu*.65)*2;
        var focus=selected==0 ? 1.025 : selected==1 ? 1.018 : 1.0;
        menuSceneCamera.zoom+=( (reduced ? 1 : focus)-menuSceneCamera.zoom)*(1-Math.exp(-elapsed*5));
        menuPaper.objects[0].color=selected==0 ? 0xFFFFFFFF : 0xFFDDCFC4;
        menuRecord.color=selected==1 ? 0xFFFFFFFF : 0xFFDDCFC4;
    }

    if (FlxG.keys.justPressed.F11) FlxG.fullscreen = !FlxG.fullscreen;
    if (leaving || inputAge < .12) return;
    if (page == "options" && (FlxG.keys.justPressed.V || cozyMobilePressed("Y"))) {
        FlxG.save.data.cozyOriginalArt = FlxG.save.data.cozyOriginalArt != true;
        FlxG.save.flush();
        openPage("options");
        return;
    }
    var back = cozyMobileBack();
    var accept = cozyMobileAccept();
    var vertical = (FlxG.keys.justPressed.DOWN || FlxG.keys.justPressed.S || cozyMobilePressed("DOWN") ? 1 : 0) - (FlxG.keys.justPressed.UP || FlxG.keys.justPressed.W || cozyMobilePressed("UP") ? 1 : 0);
    var horizontal = (FlxG.keys.justPressed.RIGHT || FlxG.keys.justPressed.D || cozyMobilePressed("RIGHT") ? 1 : 0) - (FlxG.keys.justPressed.LEFT || FlxG.keys.justPressed.A || cozyMobilePressed("LEFT") ? 1 : 0);
    if (back) {
        if (page == "intro") launchStory();
        else if (page != "home") openPage("home");
        return;
    }
    if (page == "intro") {
        if (accept) {
            introStep++;
            if (introStep > 2) launchStory();
            else refresh();
        }
        return;
    }
    if (page == "extras" || page == "credits") {
        if (accept) openPage("home");
        if (page == "credits" && horizontal != 0) {
            creditPage = (creditPage + horizontal + 3) % 3;
            refresh();
        }
        return;
    }
    if (vertical != 0 && page != "story") {
        var count = page == "freeplay" ? 4 : 5;
        selected = (selected + vertical + count) % count;
        cozySound();
        refresh();
    }
    if (page == "story" || page == "freeplay") {
        if (horizontal != 0) {
            diffIndex = (diffIndex + horizontal + 3) % 3;
            saveChoices();
            refresh();
        }
        if (FlxG.keys.justPressed.P || cozyMobilePressed("X")) {
            practice = !practice;
            saveChoices();
            refresh();
        }
    } else if (page == "options" && horizontal != 0 && selected == 3) adjustOption(horizontal);
    if (!accept) return;
    cozySound(true);
    switch (page) {
        case "home": openPage(["story", "freeplay", "options", "extras", "credits"][selected]);
        case "freeplay": launchFreeplay();
        case "story": launchStory();
        case "options": adjustOption();
    }
}

function destroy() {
    cozyMobileClear(true);
    for(m in menuMotion)cozyMotionRestore(m);
    if(menuSceneCamera!=null && FlxG.cameras.list.contains(menuSceneCamera))FlxG.cameras.remove(menuSceneCamera,true);
    if(menuUiCamera!=null && FlxG.cameras.list.contains(menuUiCamera))FlxG.cameras.remove(menuUiCamera,true);
    cozyPortraitOffsets=[];
}
